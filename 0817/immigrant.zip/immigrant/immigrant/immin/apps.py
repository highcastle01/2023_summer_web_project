from django.apps import AppConfig


class ImminConfig(AppConfig):
    name = 'immin'
