from django.contrib.auth.models import AbstractUser
from django.db import models
from .validators import validate_no_special_characters
# Create your models here.

class User(AbstractUser):
    
    user_name = models.CharField(
        max_length=15,
        null=True,
        validators=[validate_no_special_characters],
        verbose_name="이름"
    )
    
    GENDERS = (
        ('M', '남성(Man)'),
        ('W', '여성(Woman)'),
    )
    user_gender = models.CharField(verbose_name='성별', max_length=1, choices=GENDERS, null=True)

    user_birth_date = models.DateField(verbose_name="생년월일", null=True)
    user_country = models.CharField(max_length=128, verbose_name="국적", null=True)
    user_addr = models.CharField(max_length=512, verbose_name="주소", null=True)
    user_phone_num = models.CharField(max_length=32, verbose_name="전화번호", null=True)

    def __str__(self):
        return self.email
    
class Post(models.Model):
    # 글의 제목, 내용 , 작성일, 마지막 수정일
    author = models.ForeignKey(User, on_delete=models.CASCADE)
    board = models.CharField(max_length=5, verbose_name='게시판', null=True)
    bigarea = models.CharField(max_length=10, verbose_name='광역시/도', null=True)
    midarea = models.CharField(max_length=10, verbose_name='시/군/구', null=True)
    smallarea = models.CharField(max_length=10, verbose_name='동/읍/면', null=True)
    job = models.CharField(max_length=20, verbose_name='직업', null=True)
    gender = models.CharField(max_length=5, verbose_name='성별', null=True)
    title = models.CharField(max_length=50, verbose_name='제목')
    content = models.TextField()
    image1 = models.ImageField(upload_to="post_pics", blank=True)
    image2 = models.ImageField(upload_to="post_pics", blank=True)
    image3 = models.ImageField(upload_to="post_pics", blank=True)
    dt_created = models.DateTimeField(verbose_name="Date Created", auto_now_add=True)
    dt_modified = models.DateTimeField(verbose_name="Date Modified", auto_now=True)
    view_rating = models.PositiveIntegerField(default=0)
    
    def __str__(self):
        return self.title

class Comment(models.Model):
    post = models.ForeignKey(Post, on_delete=models.CASCADE) 
    content = models.TextField()
    dt_created = models.DateTimeField(verbose_name = "Date Created", auto_now_add=True)
    dt_modified = models.DateTimeField(verbose_name = "Date Modified", auto_now=True)

class Survey(models.Model):
    author = models.ForeignKey(User, on_delete=models.CASCADE)
    SCORE = (
        ('1', '매우나쁨'),
        ('2', '나쁨'),
        ('3', '보통'),
        ('4', '좋음'),
        ('5', '매우좋음'),
    )
    GENDERS = (
        ('M', '남성(Man)'),
        ('W', '여성(Woman)'),
    )
    user_gender = models.CharField(verbose_name='성별', max_length=1, choices=GENDERS)
    satisfaction = models.CharField(verbose_name='만족도', max_length=1, choices=SCORE)
    design = models.CharField(verbose_name='디자인', max_length=1, choices=SCORE)
    convenience = models.CharField(verbose_name='편리성', max_length=1, choices=SCORE)
    additional_opinion = models.CharField(verbose_name='사용자의견', max_length=300)
    