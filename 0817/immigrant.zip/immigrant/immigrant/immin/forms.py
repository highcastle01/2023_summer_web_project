from django import forms
from .models import User, Post, Comment, Survey

class SignupForm(forms.ModelForm):
    class Meta:
        model = User
        fields = ["user_name", "user_gender", "user_birth_date", "user_country", "user_addr", "user_phone_num",]
        
    def signup(self, request, user):
        user.user_name = self.cleaned_data["user_name"]
        user.user_gender = self.cleaned_data["user_gender"]
        user.user_birth_date = self.cleaned_data["user_birth_date"]
        user.user_country = self.cleaned_data["user_country"]
        user.user_addr = self.cleaned_data["user_addr"]
        user.user_phone_num = self.cleaned_data["user_phone_num"]
        user.save()
#출력
class PostForm(forms.Form):
    title = forms.CharField(max_length=50, label='제목')
    board = forms.CharField(max_length=10, label='게시판')
    bigarea = forms.CharField(max_length=10, label='광역시/도')
    midarea = forms.CharField(max_length=10, label='시/군/구')
    smallarea = forms.CharField(max_length=10, label='동/읍/면')
    job = forms.CharField(max_length=20, label='직업')
    gender = forms.CharField(max_length=5, label='성별')
    content = forms.CharField(label='내용', widget=forms.Textarea)
    image = forms.ImageField()
#입력필드
class PostForm(forms.ModelForm):
    class Meta:
        model = Post
        fields = ['title', 'board', 'bigarea', 'midarea', 'smallarea', 'job', 'gender', 'content', 'image1', 'image2', 'image3']

class CommentForm(forms.ModelForm):
    class Meta:
        model = Comment
        fields = ['content']
        
#출력
class SurveyForm(forms.Form):
    user_gender = forms.CharField(max_length=1, label='성별')
    satisfaction = forms.CharField(max_length=1, label='만족도')
    design = forms.CharField(max_length=1, label='디자인')
    convenience = forms.CharField(max_length=1, label='편리성')
    additional_opinion = forms.CharField(max_length=1, label='사용자의견')

#입력
class SurveyForm(forms.ModelForm):
    class Meta:
        model = Survey
        fields = ['user_gender', 'satisfaction', 'design', 'convenience', 'additional_opinion']